import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_svg/flutter_svg.dart';

void main() {
  runApp(OddOneOutApp());
}

class OddOneOutApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'The Odd Spark',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: OddOneOutPage(),
    );
  }
}

class OddOneOutPage extends StatefulWidget {
  @override
  _OddOneOutPageState createState() => _OddOneOutPageState();
}

class _OddOneOutPageState extends State<OddOneOutPage> {
  List<dynamic> gameData = [];
  int currentIndex = 0;
  int score = 0;
  String message = "";
  late Timer timer;
  int timeLeft = 10;
  Color backgroundColor = Colors.black;
  String characterName = "Hi! I'm Zappy the Lightning Fox";
  String characterTrait = "I will be your feedback pal!";
  String characterSvg = 'assets/images/fox.svg';
  String aiFeedback = "";

  @override
  void initState() {
    super.initState();
    fetchGameData();
  }

  Future<void> fetchGameData() async {
    final response = await http.get(Uri.parse(
        'https://us-central1-my-project-s7s1.cloudfunctions.net/bigquery-game-backend-v2'));
    if (response.statusCode == 200) {
      setState(() {
        gameData = jsonDecode(response.body)['gameData'];
        startTimer();
      });
    } else {
      setState(() {
        message = "Failed to load game data.";
      });
    }
  }

  void startTimer() {
    timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        if (timeLeft > 0) {
          timeLeft--;
        } else {
          timer.cancel();
          setState(() {
            message = "Time is up! Moving to the next set.";
          });
          Future.delayed(Duration(seconds: 2), moveToNextSet);
        }
      });
    });
  }

  void moveToNextSet() async {
    if (currentIndex < gameData.length - 1) {
      setState(() {
        currentIndex++;
        message = "";
        timeLeft = 10;
      });
      startTimer();
    } else {
      fetchAiFeedback();
    }
  }

  Future<void> fetchAiFeedback() async {
    final response = await fetchGeminiResponse(
        "Give a short 4 lines feedback on a user's game, use the number of right answers: $score, out of $gameData.length. Talk as Zappy");
    if (response.isNotEmpty &&
        response.containsKey('candidates') &&
        response['candidates'] is List &&
        response['candidates'].isNotEmpty) {
      dynamic candidate = response['candidates'][0];
      if (candidate != null &&
          candidate.containsKey('content') &&
          candidate['content'] is Map<String, dynamic>) {
        Map<String, dynamic> content = candidate['content'];

        if (content.containsKey('parts') &&
            content['parts'] is List &&
            content['parts'].isNotEmpty) {
          String feedbackMessage = content['parts'][0]['text'] ?? "";
          setState(() {
            aiFeedback = feedbackMessage;
          });
        }
      }
    }
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) =>
            FinalScorePage(score: score, total: gameData.length, aiFeedback: aiFeedback),
      ),
    );
  }

  Future<Map<String, dynamic>> fetchGeminiResponse(String prompt) async {
    const String geminiUrl =
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent";
    const String apiKey = "<>"; // Replace with your API Key

    try {
      final response = await http.post(
        Uri.parse(geminiUrl),
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": apiKey,
        },
        body: jsonEncode({
          "contents": [
            {
              "parts": [
                {"text": prompt}
              ]
            }
          ]
        }),
      );

      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);
        print("Gemini response body: $data");
        return data;
      } else {
        print("Error: ${response.statusCode} - ${response.body}");
        return {};
      }
    } catch (e) {
      print("Error: $e");
      return {};
    }
  }

  void handleSelection(String selectedItem) async {
    timer.cancel();
    final correctAnswer = gameData[currentIndex]['oddOneOut'];

    String zappyMessage = "";
     Color zappyMessageColor = Colors.lightGreenAccent; // Default color for Zappy message

    if (selectedItem == correctAnswer) {
      setState(() {
        score++;
        message = "Correct! Your current score is $score.";
      });

      final response =
          await fetchGeminiResponse("Encourage a player who scored $score points. Keep it short.");
      if (response.isNotEmpty &&
          response.containsKey('candidates') &&
          response['candidates'] is List &&
          response['candidates'].isNotEmpty) {
        dynamic candidate = response['candidates'][0];
        if (candidate != null &&
            candidate.containsKey('content') &&
            candidate['content'] is Map<String, dynamic>) {
          Map<String, dynamic> content = candidate['content'];

          if (content.containsKey('parts') &&
              content['parts'] is List &&
              content['parts'].isNotEmpty) {
            String encouragingMessage = content['parts'][0]['text'] ?? "";
            zappyMessage = "Zappy says: $encouragingMessage";
          }
        }
      }
    } else {
      setState(() {
        message = "Oops, That's Wrong!! Your  score is still $score.";
      });

      final response =
          await fetchGeminiResponse("Encourage a player who got the wrong answer. Keep it short.");
      if (response.isNotEmpty &&
          response.containsKey('candidates') &&
          response['candidates'] is List &&
          response['candidates'].isNotEmpty) {
        dynamic candidate = response['candidates'][0];
        if (candidate != null &&
            candidate.containsKey('content') &&
            candidate['content'] is Map<String, dynamic>) {
          Map<String, dynamic> content = candidate['content'];

          if (content.containsKey('parts') &&
              content['parts'] is List &&
              content['parts'].isNotEmpty) {
            String encouragingMessage = content['parts'][0]['text'] ?? "";
            zappyMessage = "Zappy says: $encouragingMessage";
           zappyMessageColor = Colors.red; // Change Zappy message color to red for wrong answer
          }
        }
      }
    }
     setState(() {
        this.message = message; // Set the main message
      if (zappyMessage.isNotEmpty) {
        this.message += "\n";
       this.message += zappyMessage;
      }
    });

    Future.delayed(Duration(seconds: 2), moveToNextSet);
  }

  @override
  Widget build(BuildContext context) {
    if (gameData.isEmpty) {
      return Scaffold(
        backgroundColor: backgroundColor,
        body: Center(child: CircularProgressIndicator(color: Colors.white,)),
      );
    }

    final currentSet = gameData[currentIndex];
    final items = List<String>.from(currentSet['items']);

    return Scaffold(
       backgroundColor: backgroundColor,
      appBar: AppBar(
        title: Center(
          child: Text(
            'The Odd Spark',
            style: TextStyle(
              fontFamily: 'PixelifySans', // Use the pixel font
              fontSize: 24,
              color: Colors.white,
            ),
          ),
        ),
        backgroundColor: Colors.transparent, // Make AppBar transparent
        elevation: 0, // Remove AppBar shadow
       ),
      body: Container(
        color: backgroundColor,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
               SvgPicture.asset(characterSvg, height: 150, width: 150),
              SizedBox(height: 20),
              Text(
                '$characterName - $characterTrait',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
              ),
              SizedBox(height: 20),
              Text(
                'Time left: $timeLeft seconds',
                style: TextStyle(fontSize: 20, color: Colors.red),
              ),
              SizedBox(height: 20),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: items.map((item) {
                  return GestureDetector(
                      onTap: () => handleSelection(item),
                      child: Container(
                        width: 120, // Increased size
                        height: 120, // Increased size
                        decoration: BoxDecoration(
                          color: Colors.blueAccent,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Center(
                          child: Text(
                            item,
                            style: TextStyle(fontSize: 18, color: Colors.white), // White text for better visibility
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ));
                }).toList(),
              ),
              SizedBox(height: 20),
               ...message.split('\n').map((line) {
                if (line.startsWith("Zappy says:")) {
                   Color messageColor = Colors.lightGreenAccent;
                   if (message.contains("Oops")){
                     messageColor = Colors.red;
                   }
                  return Container(
                    padding: EdgeInsets.all(8.0),
                    decoration: BoxDecoration(
                      color: messageColor,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      line,
                      style: TextStyle(
                        fontSize: 20,
                        fontStyle: FontStyle.italic,
                         color: Colors.black,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  );
                 }
                   else {
                  return Text(
                    line,
                     style: TextStyle(fontSize: 20, color: Colors.white),
                    textAlign: TextAlign.center,
                  );
                }
              }).toList(),
              SizedBox(height: 20),
               Text(
                'Current Score: $score/${currentIndex + 1}',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    timer.cancel();
    super.dispose();
  }
}

class FinalScorePage extends StatelessWidget {
  final int score;
  final int total;
  final String aiFeedback;

  FinalScorePage({required this.score, required this.total, required this.aiFeedback});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       backgroundColor: Colors.black,
      appBar: AppBar(
        title: Center(
          child: Text(
            'The Odd Spark',
            style: TextStyle(
              fontFamily: 'PixelifySans', // Use the pixel font
              fontSize: 24,
              color: Colors.white,
            ),
          ),
        ),
        backgroundColor: Colors.transparent, // Make AppBar transparent
        elevation: 0, // Remove AppBar shadow
       ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              'Game Over!',
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            SizedBox(height: 20),
            Text(
              'Your final score is $score out of $total.',
              style: TextStyle(fontSize: 24, color: Colors.white),
            ),
            SizedBox(height: 20),
            Text(
              aiFeedback,
              style: TextStyle(fontSize: 18, fontStyle: FontStyle.italic, color: Colors.white),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20),
            ElevatedButton(
               style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueAccent,
                ),
              onPressed: () {
                Navigator.popUntil(context, (route) => route.isFirst);
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => OddOneOutPage()),
                );
              },
              child: Text('Play Again', style: TextStyle(color: Colors.white),),
            ),
          ],
        ),
      ),
    );
  }
}