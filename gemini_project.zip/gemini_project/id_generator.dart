import 'dart:math';
String generateRandomSuffix() {
final random = Random();
return String.fromCharCodes(
    List.generate(3, (_) => 97 + random.nextInt(26))
);
}
void main() {
    print(generateRandomSuffix());
}
